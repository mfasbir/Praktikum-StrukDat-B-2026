mahasiswa = ("A001", "Budi", "Informatika")
print(mahasiswa[1])
for x in mahasiswa:
  print(x)
#alasannya untuk keamanan dan integritas data